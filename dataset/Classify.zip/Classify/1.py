import torch
from transformers import BertTokenizer, BertForSequenceClassification, AdamW
from torch.utils.data import DataLoader, Dataset
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import os

model_name = "bert-base-uncased"
tokenizer = BertTokenizer.from_pretrained(model_name)
model = BertForSequenceClassification.from_pretrained(model_name)

path = os.path.abspath(os.path.dirname(__file__)) + "/"

class NovelDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_length=128):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = self.texts[idx]
        label = self.labels[idx]
        encoding = self.tokenizer(text, truncation=True, padding='max_length', max_length=self.max_length, return_tensors='pt')
        return {'input_ids': encoding['input_ids'].squeeze(), 'attention_mask': encoding['attention_mask'].squeeze(), 'labels': label}

#训练数据集
with open(path+"1.txt", "r", encoding="utf-8") as file1:
    novel1_text = file1.read().splitlines()
with open(path+"2.txt", "r", encoding="utf-8") as file2:
    novel2_text = file2.read().splitlines()

labels_novel1 = [0] * len(novel1_text)
labels_novel2 = [1] * len(novel2_text)

texts = novel1_text + novel2_text
labels = labels_novel1 + labels_novel2

train_texts, val_texts, train_labels, val_labels = train_test_split(texts, labels, test_size=0.2)

train_dataset = NovelDataset(train_texts, train_labels, tokenizer)
val_dataset = NovelDataset(val_texts, val_labels, tokenizer)

train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=8, shuffle=False)

#训练模型
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
optimizer = AdamW(model.parameters(), lr=1e-5)


for epoch in range(10):
    model.train()
    for batch in train_loader:
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        labels = batch['labels'].to(device)
        optimizer.zero_grad()
        outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
        loss = outputs.loss
        loss.backward()
        optimizer.step()
        print("Epoch:", epoch, "Loss:", loss.item())



model.eval()
test_texts = []
with open(path+"test.txt", "r", encoding="utf-8") as file:
    test_texts = file.read().splitlines()

test_dataset = NovelDataset(test_texts, [0] * len(test_texts), tokenizer)
test_loader = DataLoader(test_dataset, batch_size=8, shuffle=False)

predictions = []
for batch in test_loader:
    input_ids = batch['input_ids'].to(device)
    attention_mask = batch['attention_mask'].to(device)
    outputs = model(input_ids, attention_mask=attention_mask)
    logits = outputs.logits
    predictions.extend(logits.argmax(dim=1).tolist())

print("Predicted labels:", predictions)


predicted_labels = ["Novel 1" if label == 0 else "Novel 2" for label in predictions]
print("Predicted labels:", predicted_labels)

